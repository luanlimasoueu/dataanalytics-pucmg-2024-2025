#include <unistd.h>
#include <stdio.h>

int main() {
    pid_t pid = fork();

    if (pid == 0) {
        // C�digo do processo filho
        printf("Hello from child process\n");
    } else {
        // C�digo do processo pai
        printf("Hello from parent process\n");
    }

    return 0;
}
