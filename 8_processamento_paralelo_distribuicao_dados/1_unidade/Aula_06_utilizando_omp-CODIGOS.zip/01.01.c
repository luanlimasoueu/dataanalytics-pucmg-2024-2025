#include <omp.h>
#include <stdio.h>
#define N 1000

int main() {
    int i, sum = 0;
    int array[N];

    // Initialize array
    for (i = 0; i < N; i++) {
        array[i] = i;
    }

    // Parallelize this loop
    #pragma omp parallel for reduction(+:sum)
    for (i = 0; i < N; i++) {
        sum += array[i];
    }

    printf("Sum: %d\n", sum);
    return 0;
}
