from mrjob.job import MRJob
from mrjob.step import MRStep

class Top5Movies(MRJob):

    def steps(self):
        return [
            MRStep(mapper=self.mapper_get_ratings,
                   reducer=self.reducer_calculate_averages),
            MRStep(reducer=self.reducer_find_top_5)
        ]

    def mapper_get_ratings(self, _, line):
       
        userID, movieID, rating, timestamp = line.split('\t')
        yield movieID, (float(rating), 1)

    def reducer_calculate_averages(self, movieID, values):
        total_rating = 0
        num_ratings = 0
        for rating, count in values:
            total_rating += rating
            num_ratings += count
        average_rating = total_rating / num_ratings
        yield None, (average_rating, movieID)

    def reducer_find_top_5(self, _, movie_ratings):

        top_5 = sorted(movie_ratings, reverse=True)[:5]
        for average_rating, movieID in top_5:
            yield movieID, average_rating

if __name__ == '__main__':
    Top5Movies.run()
