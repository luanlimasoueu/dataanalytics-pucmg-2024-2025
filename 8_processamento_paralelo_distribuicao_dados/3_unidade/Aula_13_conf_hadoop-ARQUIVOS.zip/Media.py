from mrjob.job import MRJob
from mrjob.step import MRStep

class MovieRatingsAverage(MRJob):

    def mapper(self, _, line):
        userID, movieID, rating, timestamp = line.split('\t')
        yield movieID, float(rating)

    def reducer(self, movieID, ratings):
        ratings_list = list(ratings)
        yield movieID, sum(ratings_list) / len(ratings_list)

if __name__ == '__main__':
    MovieRatingsAverage.run()
