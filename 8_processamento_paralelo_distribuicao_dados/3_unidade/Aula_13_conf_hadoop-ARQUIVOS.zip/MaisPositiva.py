from mrjob.job import MRJob
from mrjob.step import MRStep

class MostPositiveRatings(MRJob):

    def steps(self):
        return [
            MRStep(mapper=self.mapper_get_positive_ratings,
                   reducer=self.reducer_sum_positive_ratings),
            MRStep(reducer=self.reducer_find_max_positive_ratings)
        ]

    def mapper_get_positive_ratings(self, _, line):
        userID, movieID, rating, timestamp = line.split('\t')
        rating = float(rating)
        if rating >= 4.0:
            yield movieID, 1

    def reducer_sum_positive_ratings(self, movieID, counts):
        yield None, (sum(counts), movieID)

    def reducer_find_max_positive_ratings(self, _, movie_counts):
        yield max(movie_counts)

if __name__ == '__main__':
    MostPositiveRatings.run()
