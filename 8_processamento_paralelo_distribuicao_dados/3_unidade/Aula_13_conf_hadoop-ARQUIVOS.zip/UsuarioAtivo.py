from mrjob.job import MRJob
from mrjob.step import MRStep

class MostActiveUser(MRJob):

    def mapper(self, _, line):
        userID, movieID, rating, timestamp = line.split('\t')
        yield userID, 1

    def reducer(self, userID, counts):
        yield None, (sum(counts), userID)

    def reducer_find_max(self, _, user_counts):
        yield max(user_counts)

    def steps(self):
        return [
            MRStep(mapper=self.mapper,
                   reducer=self.reducer),
            MRStep(reducer=self.reducer_find_max)
        ]

if __name__ == '__main__':
    MostActiveUser.run()
